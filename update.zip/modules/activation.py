import hashlib
import uuid
from pathlib import Path

ACTIVATION_FILE = Path("activation.key")

SECRET = "NOTA_SUPER_SECRET_2025"


# استخراج رقم فريد للجهاز (Hardware ID)
def get_device_id():
    return hex(uuid.getnode())


# توليد مفتاح تفعيل بناءً على رقم الجهاز
def generate_key(device_id):
    raw = device_id + SECRET
    return hashlib.md5(raw.encode()).hexdigest()[:16].upper()


# حفظ المفتاح بعد التفعيل
def save_key(key):
    ACTIVATION_FILE.write_text(key)


# التحقق هل البرنامج مُفعّل
def is_activated():
    if not ACTIVATION_FILE.exists():
        return False

    saved_key = ACTIVATION_FILE.read_text().strip()
    expected_key = generate_key(get_device_id())

    return saved_key == expected_key


# التحقق من صحة المفتاح المُدخل
def validate_key(key):
    expected_key = generate_key(get_device_id())
    return key == expected_key
