import tkinter as tk
from tkinter import messagebox
from activation import validate_key, save_key, get_device_id


def show_help():
    messagebox.showinfo(
        "مساعدة",
        "للحصول على مفتاح التفعيل:\n\n"
        "1- قم بنسخ رقم الجهاز الظاهر في الأسفل.\n"
        "2- أرسله إلى فريق الدعم.\n"
        "3- سيتم إرسال مفتاح تفعيل خاص بجهازك فقط.\n\n"
        "للتواصل:\n"
        "Facebook: https://www.facebook.com/youssef.moneer.665919"
        "Phone: 01101270849"
    )


def open_activation():
    win = tk.Tk()
    win.title("تفعيل البرنامج")
    win.geometry("420x260")

    tk.Label(win, text="أدخل مفتاح التفعيل", font=("Arial", 11)).pack(pady=10)

    entry = tk.Entry(win, width=32)
    entry.pack(pady=5)

    # عرض رقم الجهاز للمستخدم
    device_id = get_device_id()
    tk.Label(win, text="رقم الجهاز الخاص بك:", font=("Arial", 10)).pack(pady=(10, 2))

    id_entry = tk.Entry(win, width=34)
    id_entry.insert(0, device_id)
    id_entry.config(state="readonly")
    id_entry.pack()

    btn_frame = tk.Frame(win)
    btn_frame.pack(pady=12)

    def activate():
        key = entry.get().strip()

        if validate_key(key):
            save_key(key)
            messagebox.showinfo("تم", "تم تفعيل البرنامج بنجاح")
            win.destroy()
        else:
            messagebox.showerror("خطأ", "مفتاح تفعيل غير صحيح")

    tk.Button(btn_frame, text="تفعيل", width=12, command=activate).pack(side="left", padx=5)

    # زر المساعدة
    tk.Button(
        btn_frame,
        text="؟",
        width=4,
        command=show_help
    ).pack(side="left", padx=5)

    win.mainloop()
