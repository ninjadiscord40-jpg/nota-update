import json
from pathlib import Path

CONFIG_FILE = Path("config.json")

DEFAULT = {
    "receiver_email": ""
}

def load_config():
    if not CONFIG_FILE.exists():
        save_config(DEFAULT)
    return json.loads(CONFIG_FILE.read_text())

def save_config(data):
    CONFIG_FILE.write_text(json.dumps(data, indent=4))
