import sqlite3
from pathlib import Path

DB_PATH = Path("NewNota.db")

def get_conn():
    return sqlite3.connect(DB_PATH)


def init_db():
    conn = get_conn()
    c = conn.cursor()

    # مستخدمين
    c.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','employee'))
    )""")

    # عملاء
    c.execute("""
    CREATE TABLE IF NOT EXISTS clients(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        balance REAL NOT NULL DEFAULT 0
    )""")

    # سجل العمليات مع note
    c.execute("""
    CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('add','subtract')),
        amount REAL NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        client_name TEXT,
        note TEXT,
        FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )""")

    # التحقق من الأعمدة وإضافتها لو ناقصة
    c.execute("PRAGMA table_info(transactions)")
    cols = [row[1] for row in c.fetchall()]

    if "client_name" not in cols:
        c.execute("ALTER TABLE transactions ADD COLUMN client_name TEXT")
        c.execute("""
            UPDATE transactions
            SET client_name = (
                SELECT name FROM clients
                WHERE clients.id = transactions.client_id
            )
            WHERE client_name IS NULL OR client_name = ''
        """)

    if "note" not in cols:
        c.execute("ALTER TABLE transactions ADD COLUMN note TEXT")

    # أدمن افتراضي
    c.execute("SELECT 1 FROM users WHERE username='admin'")
    if not c.fetchone():
        c.execute(
            "INSERT INTO users(username,password,role) VALUES(?,?,?)",
            ("admin", "1234", "admin")
        )

    conn.commit()
    conn.close()


# -------------------------
# وظائف عامة
# -------------------------

def fetchall(query, params=()):
    con = get_conn()
    cur = con.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    con.close()
    return rows


def execute(query, params=()):
    con = get_conn()
    cur = con.cursor()
    cur.execute(query, params)
    con.commit()
    con.close()


# -------------------------
# المستخدمين
# -------------------------

def get_user(username, password):
    rows = fetchall(
        "SELECT id, role FROM users WHERE username=? AND password=?",
        (username, password)
    )
    return rows[0] if rows else None


def list_employees():
    return fetchall(
        "SELECT id, username, role FROM users ORDER BY username"
    )


def add_employee(username, password, role):
    execute(
        "INSERT INTO users(username,password,role) VALUES(?,?,?)",
        (username, password, role)
    )


def update_employee(user_id, username, password, role):
    if password:
        execute(
            "UPDATE users SET username=?, password=?, role=? WHERE id=?",
            (username, password, role, user_id)
        )
    else:
        execute(
            "UPDATE users SET username=?, role=? WHERE id=?",
            (username, role, user_id)
        )


def delete_employee(user_id):
    execute("DELETE FROM users WHERE id=?", (user_id,))


# -------------------------
# العملاء
# -------------------------

def add_client(name):
    execute("INSERT INTO clients(name) VALUES(?)", (name,))


# ✅ الترتيب الجديد حسب أعلى رصيد
def list_clients(search=""):

    if search:
        return fetchall(
            """
            SELECT id, name, balance
            FROM clients
            WHERE name LIKE ?
            ORDER BY balance DESC, name ASC
            """,
            (f"%{search}%",)
        )

    return fetchall(
        """
        SELECT id, name, balance
        FROM clients
        ORDER BY balance DESC, name ASC
        """
    )


def get_total():
    rows = fetchall(
        "SELECT COALESCE(SUM(balance),0) FROM clients"
    )
    return rows[0][0] if rows else 0.0


# -------------------------
# تغيير الرصيد مع note
# -------------------------

def change_balance(client_id, user_id, op_type, amount, note=""):

    rows = fetchall(
        "SELECT balance, name FROM clients WHERE id=?",
        (client_id,)
    )

    if not rows:
        return False, "العميل غير موجود"

    bal, cname = rows[0]
    amount = float(amount)

    if amount <= 0:
        return False, "المبلغ يجب أن يكون أكبر من صفر"

    # إضافة
    if op_type == "add":

        new_bal = bal + amount

        execute(
            "UPDATE clients SET balance=? WHERE id=?",
            (new_bal, client_id)
        )

        execute("""
        INSERT INTO transactions(
            client_id,
            user_id,
            type,
            amount,
            client_name,
            note
        )
        VALUES(?,?,?,?,?,?)
        """,
        (
            client_id,
            user_id,
            "add",
            amount,
            cname,
            note
        ))

        return True, new_bal

    # خصم
    else:

        if bal - amount < 0:
            return False, "لا يمكن أن يقل الرصيد عن 0"

        new_bal = bal - amount

        if new_bal == 0:

            execute(
                "DELETE FROM clients WHERE id=?",
                (client_id,)
            )

        else:

            execute(
                "UPDATE clients SET balance=? WHERE id=?",
                (new_bal, client_id)
            )

        execute("""
        INSERT INTO transactions(
            client_id,
            user_id,
            type,
            amount,
            client_name,
            note
        )
        VALUES(?,?,?,?,?,?)
        """,
        (
            client_id,
            user_id,
            "subtract",
            amount,
            cname,
            note
        ))

        return True, new_bal


# -------------------------
# السجل
# -------------------------

def list_logs(limit=200):

    q = """
    SELECT
        t.created_at,
        u.username,
        t.type,
        t.amount,
        t.client_name,
        t.note
    FROM transactions t
    JOIN users u ON u.id = t.user_id
    ORDER BY t.id DESC
    LIMIT ?
    """

    return fetchall(q, (limit,))
