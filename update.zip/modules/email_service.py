import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from database.db import list_clients, get_total, list_logs

# ===== استيراد إعدادات المستخدم =====
from config import load_config
# ====================================


# ======== إعدادات الإيميل الثابتة ========
SENDER_EMAIL = "youssefmoneer19@gmail.com"
APP_PASSWORD = "hlir lkpc adtu jzck"
# ========================================


def get_receiver_email():

    cfg = load_config()

    return cfg.get("receiver_email")


# ========================================

def send_email(subject, body):

    receiver = get_receiver_email()

    if not receiver:

        print("No receiver email configured")

        return

    try:

        msg = MIMEMultipart()

        msg["From"] = SENDER_EMAIL

        msg["To"] = receiver

        msg["Subject"] = subject

        msg.attach(
            MIMEText(body, "plain", "utf-8")
        )

        server = smtplib.SMTP("smtp.gmail.com", 587)

        server.starttls()

        server.login(SENDER_EMAIL, APP_PASSWORD)

        server.send_message(msg)

        server.quit()

    except Exception as e:

        print("Email Error:", e)


# ========================================

def send_clients_report():

    clients = list_clients()

    total = get_total()

    body = "تقرير العملاء الحالي:\n\n"

    body += "الاسم\t|\tالرصيد\n"

    body += "--------------------------\n"

    for c in clients:

        body += f"{c[1]}\t|\t{c[2]}\n"

    body += "\n--------------------------\n"

    body += f"إجمالي المديونية: {total} ج.م\n"

    body += f"تاريخ الإرسال: {datetime.now()}\n"

    send_email("تقرير العملاء", body)


# ========================================

def send_logs_report():

    logs = list_logs(1000)

    body = "تقرير السجل الكامل:\n\n"

    body += "الوقت | الموظف | النوع | المبلغ | العميل | الملاحظة\n"

    body += "----------------------------------------------------------\n"

    for log in logs:

        dt, user, typ, amount, client, note = log

        note_text = note if note else ""

        body += f"{dt} | {user} | {typ} | {amount} | {client} | {note_text}\n"

    body += f"\nتاريخ الإرسال: {datetime.now()}\n"

    send_email("تقرير السجل", body)


# ========================================
# 🔥 تم التعديل هنا لدعم note
# ========================================

def send_operation_notification(op_type, client_name, amount, username, note=""):

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    note_text = note if note else "لا يوجد"

    if op_type == "add":

        subject = "إشعار إضافة مبلغ"

        body = f"""
تم عمل إضافة على حساب العميل

العميل: {client_name}

المبلغ: {amount}

الموظف: {username}

التاريخ: {now}

الملاحظة:
{note_text}
"""

    else:

        subject = "إشعار خصم مبلغ"

        body = f"""
تم عمل خصم من حساب العميل

العميل: {client_name}

المبلغ: {amount}

الموظف: {username}

التاريخ: {now}

الملاحظة:
{note_text}
"""

    send_email(subject, body)
