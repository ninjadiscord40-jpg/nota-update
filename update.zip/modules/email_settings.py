import tkinter as tk
from tkinter import messagebox
from config import load_config, save_config

def open_email_settings():
    cfg = load_config()

    win = tk.Tk()
    win.title("إعدادات الإيميل")
    win.geometry("380x200")

    tk.Label(win, text="أدخل الإيميل المستقبل للتقارير").pack(pady=10)

    entry = tk.Entry(win, width=35)
    entry.insert(0, cfg.get("receiver_email", ""))
    entry.pack()

    def save():
        email = entry.get().strip()

        if not email:
            messagebox.showerror("خطأ", "أدخل إيميل صحيح")
            return

        cfg["receiver_email"] = email
        save_config(cfg)

        messagebox.showinfo("تم", "تم حفظ الإيميل بنجاح")
        win.destroy()

    tk.Button(win, text="حفظ", command=save).pack(pady=10)

    win.mainloop()
