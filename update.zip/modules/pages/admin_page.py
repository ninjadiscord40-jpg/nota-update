import tkinter as tk
from tkinter import ttk, messagebox
from database.db import (
    list_employees,
    add_employee,
    update_employee,
    delete_employee,
    list_clients,
    get_total,
    list_logs
)
import ui.style as S


def open_admin(user_id, username):

    win = tk.Tk()

    win.title(f"لوحة الأدمن - {username}")

    win.configure(bg=S.BG)

    win.geometry("900x520")  # كبرنا العرض قليلًا عشان عمود الملاحظة


    # =========================
    # شريط علوي - إجمالي
    # =========================

    total_lbl = tk.Label(
        win,
        text="",
        bg=S.BG,
        fg=S.SUCCESS,
        font=S.FONT_TOTAL
    )

    total_lbl.pack(pady=(S.PAD, S.PAD//2))


    # =========================
    # التبويبات
    # =========================

    tabs = ttk.Notebook(win)

    tabs.pack(
        fill="both",
        expand=True,
        padx=S.PAD,
        pady=S.PAD
    )


    # =========================
    # تبويب العملاء
    # =========================

    frm_clients = tk.Frame(tabs, bg=S.BG)

    tabs.add(frm_clients, text="العملاء")

    top = tk.Frame(frm_clients, bg=S.BG)

    top.pack(fill="x", pady=(S.PAD, 6))

    tk.Label(
        top,
        text="بحث:",
        bg=S.BG,
        font=S.FONT
    ).pack(side="right")

    search_e = tk.Entry(
        top,
        width=30,
        font=S.FONT
    )

    search_e.pack(side="right", padx=6)


    cols = ("id", "name", "balance")

    tree = ttk.Treeview(
        frm_clients,
        columns=cols,
        show="headings",
        height=12
    )

    for c, t in zip(cols, ("ID", "الاسم", "الرصيد")):

        tree.heading(c, text=t)

    tree.pack(
        fill="both",
        expand=True,
        padx=S.PAD,
        pady=6
    )


    def load_clients():

        for i in tree.get_children():

            tree.delete(i)

        for row in list_clients(search_e.get().strip()):

            tree.insert("", "end", values=row)

        total_lbl.config(
            text=f"إجمالي المديونية: {get_total()} ج.م"
        )


    search_e.bind("<KeyRelease>", lambda e: load_clients())

    load_clients()


    # =========================
    # تبويب الموظفين
    # =========================

    frm_users = tk.Frame(tabs, bg=S.BG)

    tabs.add(frm_users, text="الموظفون")


    u_tree = ttk.Treeview(
        frm_users,
        columns=("id", "username", "role"),
        show="headings",
        height=12
    )

    for c, t in zip(
        ("id", "username", "role"),
        ("ID", "المستخدم", "الدور")
    ):

        u_tree.heading(c, text=t)

    u_tree.pack(
        fill="both",
        expand=True,
        padx=S.PAD,
        pady=S.PAD
    )


    def refresh_users():

        for i in u_tree.get_children():

            u_tree.delete(i)

        for r in list_employees():

            u_tree.insert("", "end", values=r)


    refresh_users()


    btns = tk.Frame(frm_users, bg=S.BG)

    btns.pack(pady=4)


    def add_user_dialog():

        dialog_user(
            frm_users,
            title="إضافة موظف",
            save_cb=lambda u, p, r:
            (
                add_employee(u, p, r),
                refresh_users()
            )
        )


    def edit_user_dialog():

        sel = u_tree.selection()

        if not sel:
            return

        row = u_tree.item(sel[0])["values"]

        dialog_user(
            frm_users,
            row,
            title="تعديل موظف",
            save_cb=lambda u, p, r:
            (
                update_employee(row[0], u, p, r),
                refresh_users()
            )
        )


    def del_user():

        sel = u_tree.selection()

        if not sel:
            return

        row = u_tree.item(sel[0])["values"]

        if row[1] == "admin":

            messagebox.showerror(
                "رفض",
                "لا يمكن حذف الأدمن الرئيسي"
            )

            return

        if messagebox.askyesno(
            "تأكيد",
            f"حذف المستخدم {row[1]}؟"
        ):

            delete_employee(row[0])

            refresh_users()


    tk.Button(
        btns,
        text="إضافة",
        width=S.BTN_W,
        bg=S.PRIMARY,
        fg="white",
        command=add_user_dialog
    ).pack(side="left", padx=6)


    tk.Button(
        btns,
        text="تعديل",
        width=S.BTN_W,
        command=edit_user_dialog
    ).pack(side="left", padx=6)


    tk.Button(
        btns,
        text="حذف",
        width=S.BTN_W,
        bg=S.DANGER,
        fg="white",
        command=del_user
    ).pack(side="left", padx=6)


    # =========================
    # تبويب السجل (تم إضافة الملاحظة)
    # =========================

    frm_logs = tk.Frame(tabs, bg=S.BG)

    tabs.add(frm_logs, text="السجل")


    log_tree = ttk.Treeview(
        frm_logs,
        columns=(
            "dt",
            "user",
            "type",
            "amount",
            "client",
            "note"
        ),
        show="headings",
        height=14
    )


    for c, t in zip(
        ("dt", "user", "type", "amount", "client", "note"),
        ("الوقت", "الموظف", "النوع", "المبلغ", "العميل", "الملاحظة")
    ):

        log_tree.heading(c, text=t)


    log_tree.pack(
        fill="both",
        expand=True,
        padx=S.PAD,
        pady=S.PAD
    )


    def load_logs():

        for i in log_tree.get_children():

            log_tree.delete(i)

        logs = list_logs(400)

        for log in logs:

            dt, user, typ, amount, client, note = log

            note_text = note if note else ""

            log_tree.insert(
                "",
                "end",
                values=(
                    dt,
                    user,
                    typ,
                    amount,
                    client,
                    note_text
                )
            )


    load_logs()


    # =========================
    # زر تحديث
    # =========================

    topbar = tk.Frame(win, bg=S.BG)

    topbar.pack(side="bottom", fill="x")


    tk.Button(
        topbar,
        text="تحديث",
        command=lambda:
        (
            load_clients(),
            refresh_users(),
            load_logs()
        ),
        width=S.BTN_W
    ).pack(pady=6)


    win.mainloop()


# =========================
# نافذة المستخدم
# =========================

def dialog_user(parent, row=None, title="مستخدم", save_cb=None):

    d = tk.Toplevel(parent)

    d.title(title)

    d.configure(bg=S.BG)

    d.geometry("320x250")


    tk.Label(
        d,
        text="اسم المستخدم",
        bg=S.BG,
        font=S.FONT
    ).pack(pady=(12, 4))


    u_e = tk.Entry(
        d,
        width=28,
        font=S.FONT
    )

    u_e.pack()


    tk.Label(
        d,
        text="كلمة المرور",
        bg=S.BG,
        font=S.FONT
    ).pack(pady=(12, 4))


    p_e = tk.Entry(
        d,
        show="*",
        width=28,
        font=S.FONT
    )

    p_e.pack()


    tk.Label(
        d,
        text="الدور (admin/employee)",
        bg=S.BG,
        font=S.FONT
    ).pack(pady=(12, 4))


    r_e = tk.Entry(
        d,
        width=28,
        font=S.FONT
    )

    r_e.pack()


    if row:

        u_e.insert(0, row[1])

        r_e.insert(0, row[2])


    def save():

        u = u_e.get().strip()

        p = p_e.get().strip()

        r = r_e.get().strip() or "employee"

        if not u:
            return

        try:

            if save_cb:

                save_cb(u, p, r)

            d.destroy()

        except Exception as e:

            messagebox.showerror(
                "خطأ",
                str(e)
            )


    tk.Button(
        d,
        text="حفظ",
        width=S.BTN_W,
        bg=S.PRIMARY,
        fg="white",
        command=save
    ).pack(pady=14)
