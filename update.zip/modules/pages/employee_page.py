import tkinter as tk
from tkinter import ttk, messagebox
from database.db import list_clients, add_client, change_balance, get_total
import ui.style as S

# ===== استيراد خدمة الإيميل =====
from email_service import send_clients_report, send_logs_report, send_operation_notification
# ===============================


def open_employee(user_id, username):

    win = tk.Tk()
    win.title(f"لوحة الموظف - {username}")
    win.configure(bg=S.BG)
    win.geometry("820x520")

    # إجمالي أعلى الشاشة
    total_lbl = tk.Label(
        win,
        text="",
        bg=S.BG,
        fg=S.SUCCESS,
        font=S.FONT_TOTAL
    )
    total_lbl.pack(pady=(S.PAD, S.PAD//2))

    # صف إدخال عميل جديد + بحث
    bar = tk.Frame(win, bg=S.BG)
    bar.pack(fill="x", padx=S.PAD)

    name_e = tk.Entry(bar, width=30, font=S.FONT)
    name_e.pack(side="right", padx=6)

    tk.Button(
        bar,
        text="إضافة عميل",
        width=S.BTN_W,
        bg=S.PRIMARY,
        fg="white",
        command=lambda: add_client_safe()
    ).pack(side="right", padx=6)

    search_e = tk.Entry(bar, width=28, font=S.FONT)
    search_e.pack(side="left", padx=6)

    tk.Label(
        bar,
        text="بحث:",
        bg=S.BG,
        font=S.FONT
    ).pack(side="left")

    # جدول العملاء
    cols = ("id", "name", "balance")

    tree = ttk.Treeview(
        win,
        columns=cols,
        show="headings",
        height=12
    )

    for c, t in zip(cols, ("ID", "الاسم", "الرصيد")):
        tree.heading(c, text=t)

    tree.pack(fill="both", expand=True, padx=S.PAD, pady=6)

    # شريط العمليات
    ops = tk.Frame(win, bg=S.BG)
    ops.pack(pady=(4, S.PAD))

    tk.Label(
        ops,
        text="المبلغ:",
        bg=S.BG,
        font=S.FONT
    ).pack(side="right", padx=6)

    amount_e = tk.Entry(
        ops,
        width=18,
        font=S.FONT
    )
    amount_e.pack(side="right", padx=6)

    tk.Button(
        ops,
        text="إضافة",
        width=S.BTN_W,
        bg=S.PRIMARY,
        fg="white",
        command=lambda: do_change("add")
    ).pack(side="left", padx=6)

    tk.Button(
        ops,
        text="خصم",
        width=S.BTN_W,
        bg=S.DANGER,
        fg="white",
        command=lambda: do_change("subtract")
    ).pack(side="left", padx=6)

    tk.Button(
        ops,
        text="إرسال تقارير",
        width=S.BTN_W,
        bg="green",
        fg="white",
        command=lambda: send_reports()
    ).pack(side="left", padx=6)

    # =========================

    def refresh():

        for i in tree.get_children():
            tree.delete(i)

        for r in list_clients(search_e.get().strip()):
            tree.insert("", "end", values=r)

        total_lbl.config(
            text=f"إجمالي المديونية: {get_total()} ج.م"
        )

    def on_search(_=None):
        refresh()

    search_e.bind("<KeyRelease>", on_search)

    # =========================

    def add_client_safe():

        name = name_e.get().strip()

        if not name:
            messagebox.showerror(
                "خطأ",
                "أدخل اسم العميل"
            )
            return

        try:

            add_client(name)

            name_e.delete(0, tk.END)

            refresh()

        except Exception as e:

            messagebox.showerror(
                "خطأ",
                f"لا يمكن إضافة العميل: {e}"
            )

    # =========================
    # 🔥 تم تعديل هذه الدالة لإضافة الملاحظة
    # =========================

    def do_change(op_type):

        sel = tree.selection()

        if not sel:

            messagebox.showwarning(
                "تنبيه",
                "اختر عميلًا أولًا من الجدول"
            )

            return

        amount_txt = amount_e.get().strip()

        try:

            amount = float(amount_txt)

            if amount <= 0:
                raise ValueError

        except:

            messagebox.showerror(
                "خطأ",
                "أدخل مبلغًا صحيحًا أكبر من صفر"
            )

            return

        row = tree.item(sel[0])["values"]

        client_id = row[0]
        cname = row[1]

        verb = "إضافة" if op_type == "add" else "خصم"

        # =========================
        # نافذة إدخال الملاحظة
        # =========================

        note_win = tk.Toplevel(win)

        note_win.title("تأكيد العملية")

        note_win.geometry("350x220")

        tk.Label(
            note_win,
            text=f"{verb} مبلغ {amount} للعميل:\n{cname}",
            font=S.FONT
        ).pack(pady=10)

        tk.Label(
            note_win,
            text="الملاحظة (اختياري):",
            font=S.FONT
        ).pack()

        note_entry = tk.Entry(
            note_win,
            width=35,
            font=S.FONT
        )

        note_entry.pack(pady=5)

        def confirm():

            note = note_entry.get().strip()

            ok, msg = change_balance(
                client_id,
                user_id,
                op_type,
                amount,
                note
            )

            if ok:

                amount_e.delete(0, tk.END)

                refresh()

                note_win.destroy()

                # إرسال الإيميل مع الملاحظة
                try:

                    send_operation_notification(
                        op_type,
                        cname,
                        amount,
                        username,
                        note
                    )

                except Exception as e:

                    print("Email notification failed:", e)

            else:

                messagebox.showerror(
                    "فشل العملية",
                    msg
                )

        tk.Button(
            note_win,
            text="تأكيد",
            bg=S.PRIMARY,
            fg="white",
            width=12,
            command=confirm
        ).pack(pady=10)

    # =========================

    def send_reports():

        try:

            send_clients_report()

            send_logs_report()

            messagebox.showinfo(
                "تم",
                "تم إرسال التقارير بنجاح عبر البريد الإلكتروني"
            )

        except Exception as e:

            messagebox.showerror(
                "خطأ",
                f"فشل إرسال التقارير: {e}"
            )

    # =========================

    refresh()

    win.mainloop()
