import tkinter as tk
from tkinter import messagebox
from database.db import get_user
from pages.admin_page import open_admin
from pages.employee_page import open_employee
import ui.style as S

def open_login():
    root = tk.Tk()
    root.title("نوته - تسجيل الدخول")
    root.configure(bg=S.BG)
    root.geometry("360x220")

    tk.Label(root, text="اسم المستخدم", bg=S.BG, fg=S.FG, font=S.FONT).pack(pady=(S.PAD, 4))
    user_e = tk.Entry(root, width=S.ENTRY_W, font=S.FONT)
    user_e.pack()

    tk.Label(root, text="كلمة المرور", bg=S.BG, fg=S.FG, font=S.FONT).pack(pady=(S.PAD, 4))
    pass_e = tk.Entry(root, show="*", width=S.ENTRY_W, font=S.FONT)
    pass_e.pack()

    def do_login():
        u, p = user_e.get().strip(), pass_e.get().strip()
        data = get_user(u, p)
        if not data:
            messagebox.showerror("خطأ", "بيانات الدخول غير صحيحة")
            return
        uid, role = data
        root.destroy()
        if role == "admin":
            open_admin(uid, u)
        else:
            open_employee(uid, u)

    tk.Button(root, text="دخول", width=S.BTN_W, bg=S.PRIMARY, fg="white",
              font=S.FONT_BOLD, command=do_login).pack(pady=S.PAD)

    root.mainloop()
